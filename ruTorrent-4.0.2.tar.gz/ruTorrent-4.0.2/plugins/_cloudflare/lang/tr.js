﻿/* PLUGIN _CLOUDFLARE
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare eklentisi: Python, cloudscraper modülünü kullanamıyor";

thePlugins.get("_cloudflare").langLoaded();
