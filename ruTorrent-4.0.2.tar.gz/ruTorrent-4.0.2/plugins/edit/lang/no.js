﻿/*
 * PLUGIN EDIT
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.EditTrackers			= "Rediger torrent...";
 theUILang.EditTorrentProperties	= "Torrentegenskaper";
 theUILang.errorAddTorrent		= "Feil oppstod ved å legge til torrentfil";
 theUILang.errorWriteTorrent		= "Feil oppstod ved å skrive til torrentfil";
 theUILang.errorReadTorrent		= "Feil oppstod ved å lese fra torrentfil";
 theUILang.cantFindTorrent		= "Kilde-torrentfil for denne nedlastingen ble ikke funnet."

thePlugins.get("edit").langLoaded();