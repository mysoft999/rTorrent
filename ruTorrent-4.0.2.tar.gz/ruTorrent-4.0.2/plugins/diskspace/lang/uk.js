﻿/*
 * PLUGIN DISKSPACE
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.diskNotification	= "Попередження! Диск заповнено. Програма rTorrent може працювати некоректно, а дані не завантажуватимуться, поки не з’явиться вільне місце на диску.";

thePlugins.get("diskspace").langLoaded();