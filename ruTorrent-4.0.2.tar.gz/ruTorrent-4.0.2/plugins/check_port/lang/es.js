﻿/*
 * PLUGIN CHECK_PORT
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.checkWebsiteNotFound = "Check_port plugin: Plugin will not work. Invalid configuration";
 theUILang.checkPort		= "Verificar estado del puerto";
 theUILang.portStatus		= [
 				  "Es estado del puerto es desconocido",
 				  "Puerto cerrado",
 				  "Puerto abierto"
 				  ];

thePlugins.get("check_port").langLoaded();