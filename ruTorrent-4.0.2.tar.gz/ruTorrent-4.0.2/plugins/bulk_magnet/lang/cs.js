﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Czech language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Copy";
 theUILang.Magnet		= "Magnet link";
 theUILang.bulkAdd		= "Bulk loading"; 
 theUILang.bulkAddDescription	= "One link per line (HTTP, magnet-link or hash)";

thePlugins.get("bulk_magnet").langLoaded();