﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Turkish language file.
 *
 * Author: Müslüm Barış Korkmazer (bkbabinco@gmail.com)
 */

 theUILang.bulkCopy		= "Kopyala";
 theUILang.Magnet		= "Magnet linki";
 theUILang.bulkAdd		= "Bulk loading"; 
 theUILang.bulkAddDescription	= "Her satır için bir link (HTTP, magnet-link ya da hash)";

thePlugins.get("bulk_magnet").langLoaded();
