﻿/*
 * PLUGIN CREATE
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.mnu_create			= "Lag torrent...";
 theUILang.CreateNewTorrent		= "Lag ny torrent";
 theUILang.SelectSource			= "Velg kilde";
 theUILang.TorrentProperties		= "Torrentegenskaper";
 theUILang.PieceSize			= "Delstørrelse";
 theUILang.Other			= "Annet";
 theUILang.StartSeeding			= "Start seeding";
 theUILang.PrivateTorrent		= "Privat torrent";
 theUILang.torrentCreate		= "Lag...";
 theUILang.BadTorrentData		= "Du må fylle ut alle påkrevde felt!";
 theUILang.createExternalNotFound	= "Opprett plugin: Plugin vil ikke funke. Webserver-brukeren har ikke tilgang til eksternt program";
 theUILang.incorrectDirectory		= "Ugyldig mappe";
 theUILang.cantExecExternal		= "Kan ikke kjøre eksternt program";
 theUILang.createConsole		= "Konsoll";
 theUILang.createErrors			= "Feilmeldinger";
 theUILang.torrentSave			= "Lagre";
 theUILang.torrentKill			= "Stopp";
 theUILang.torrentKilled		= "Prosessen ble stoppet.";
 theUILang.recentTrackers		= "Nylige trackere";
 theUILang.source			    = "Kilde";
 theUILang.HybridTorrent		= "Hybrid torrent";
 theUILang.deleteFromRecentTrackers	= "> Slett";

thePlugins.get("create").langLoaded();