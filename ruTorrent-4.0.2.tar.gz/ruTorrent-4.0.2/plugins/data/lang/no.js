﻿/*
 * PLUGIN DATA
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.getData		= "Hent fil";
 theUILang.cantAccessData	= "Webserver-brukeren har ikke tilgang til dataen til denne torrenten.";

thePlugins.get("data").langLoaded();