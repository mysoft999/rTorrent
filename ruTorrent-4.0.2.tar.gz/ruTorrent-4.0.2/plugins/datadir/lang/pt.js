﻿/*
 * PLUGIN DATADIR
 *
 * Portuguese language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Save to";
 theUILang.DataDirMove		= "Move data files";
 theUILang.datadirDlgCaption	= "Torrent Data Directory";
 theUILang.datadirDirNotFound	= "DataDir plugin: Invalid directory";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operation fail";

thePlugins.get("datadir").langLoaded();