﻿/*
 * PLUGIN DATADIR
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.DataDir		= "Chemin";
 theUILang.DataDirMove		= "Déplacer les fichiers";
 theUILang.datadirDlgCaption	= "Répertoire du torrent";
 theUILang.datadirDirNotFound	= "Plugin 'DataDir' : Répertoire invalide";
 theUILang.datadirSetDirFail	= "Plugin 'DataDir' : L'opération a échoué";

thePlugins.get("datadir").langLoaded();
